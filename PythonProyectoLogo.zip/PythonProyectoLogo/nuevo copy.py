import numpy as np
import cv2 


rostros = cv2.CascadeClassifier('haarcascade_frontalface_alt.xml')
ojos = cv2.CascadeClassifier('haarcascade_eye.xml')

#---------aqui va el video
cap = cv2.VideoCapture('video.mp4')

while True:



    ret,img=cap.read()
    cv2.imshow('foto1',img)
    #---------escala de grises
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    #cv2.imshow('foto2',gray)

    #---------blur
    blur=cv2.GaussianBlur(img,(11,11),10)
    #cv2.imshow('foto2',blur)

    #---------contornos
    canny = cv2.Canny(blur, 50, 150)
    cv2.imshow('foto2',canny)    
    #---------esquinas
    gray = np.float32(gray)
    dst = cv2.cornerHarris(gray,2,3,0.04)
    #cv2.imshow('foto2',dst)

    print('mostrando')
    k=cv2.waitKey(30) & 0xff
    if k==27:
        break


cap.release()
cv2.destroyAllWindows()