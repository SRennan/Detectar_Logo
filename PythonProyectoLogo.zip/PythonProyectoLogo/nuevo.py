import numpy as np
import cv2 




rostros = cv2.CascadeClassifier('haarcascade_frontalface_alt.xml')
ojos = cv2.CascadeClassifier('haarcascade_eye.xml')
upds=cv2.CascadeClassifier('myhaar.xml')
upds2=cv2.CascadeClassifier('myhaar2.xml')
upds3=cv2.CascadeClassifier('myhaar3.xml')

#---------aqui va el video
cap = cv2.VideoCapture('videoUPDS.mp4')

while True:



    ret,img=cap.read()

    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    
   
    #logo=upds3.detectMultiScale(gray,scaleFactor=1.5,minSize=(10,10),maxSize=(100,100))
    
    logo=upds2.detectMultiScale(gray,scaleFactor=1.5,minNeighbors=30,minSize=(50,50),maxSize=(100,100))
   # logo=upds.detectMultiScale(gray,minSize=(10,10),maxSize=(100,100))

    

    
    for(x,y,w,h) in logo:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
        
   

    print('mostrando')
    cv2.imshow('foto1',img)
    k=cv2.waitKey(30) & 0xff
    if k==27:
        break


cap.release()
cv2.destroyAllWindows()